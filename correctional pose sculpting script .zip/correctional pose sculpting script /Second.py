import c4d


def main():
    obj = doc.GetActiveObject()
    if not obj : return False
    pmTag = obj.GetTag(c4d.Tposemorph)
    if not pmTag : return False
    corr = obj.GetDownLast()
    skin_1 = corr.GetPred()
    skin_2 = corr.GetPred().GetPred()
    skin_1[c4d.ID_BASEOBJECT_GENERATOR_FLAG]=False
    if skin_2:skin_2[c4d.ID_BASEOBJECT_GENERATOR_FLAG]=False
    doc.ExecutePasses(None, False, False, True, c4d.BUILDFLAGS_0)
    corr[c4d.ID_BASEOBJECT_GENERATOR_FLAG]=False
    pmTag.AddMorph()
    pmTag.UpdateMorphs()    
    pmTag[c4d.EXPRESSION_ENABLE]=True
    count = pmTag.GetMorphCount()
    pmTag.SetActiveMorphIndex(count-1) 
    pmTag[c4d.ID_CA_POSE_TARGET] = corr
    doc.ExecutePasses(None, False, True, False, c4d.BUILDFLAGS_0)  
    pmTag[c4d.ID_CA_POSE_TARGET] = None 
    skin_1[c4d.ID_BASEOBJECT_GENERATOR_FLAG]=True
    if skin_2:skin_2[c4d.ID_BASEOBJECT_GENERATOR_FLAG]=True     
    pmTag[c4d.ID_CA_POSE_MIXING]=3
    pmTag[c4d.ID_CA_POSE_MIXING_DEFORMED]=True
    c4d.EventAdd()

if __name__=='__main__':
    main()

import c4d


def main():
    obj = doc.GetActiveObject()
    if not obj : return False
    pmTag = obj.GetTag(c4d.Tposemorph)
    if not pmTag :
        pmTag = c4d.BaseTag(c4d.Tposemorph)
        obj.InsertTag(pmTag)
        pmTag[c4d.ID_CA_POSE_POINTS]=True
        pmTag.AddMorph()
        pmTag.UpdateMorphs()
    pmTag[c4d.EXPRESSION_ENABLE]=False
    corr = c4d.BaseObject(1024542) #define the correction deformer
    corr.Message(c4d.MSG_MENUPREPARE)
    doc.InsertObject(corr,obj,obj.GetDownLast(),True)
    doc.SetActiveObject(corr)    
    c4d.EventAdd()


if __name__=='__main__':
    main()
